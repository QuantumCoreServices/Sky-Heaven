import uvicorn
from fastapi import FastAPI
from mangum import Mangum  # Add this line

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Hello, World!"}

# This makes the app work with AWS Lambda
handler = Mangum(app)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
